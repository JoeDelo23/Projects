-- Task 2) 
-- Creazione della tabella Product
CREATE TABLE Product (
    ProductID INT PRIMARY KEY,
    ProductName VARCHAR(100),
    ProductDescription VARCHAR(255),
    ProductCategory VARCHAR(50)
);

-- Creazione della tabella Region
CREATE TABLE Region (
    RegionID INT PRIMARY KEY,
    RegionName VARCHAR(100),
    RegionState VARCHAR(255)
);

-- Creazione della tabella Sales
CREATE TABLE Sales (
    SaleID INT PRIMARY KEY,
    SaleDate DATE,
    Amount DECIMAL(10, 2),
    ProductID INT,
    RegionID INT,
    FOREIGN KEY (ProductID) REFERENCES Product(ProductID),
    FOREIGN KEY (RegionID) REFERENCES Region(RegionID)
);

-- Task 3)
-- Popolamento della tabella Product
INSERT INTO Product (ProductID, ProductName, ProductDescription, ProductCategory)
VALUES 
	(1, 'Pikachu Plush', 'Indoor Doll', 'Toys'),
	(2, 'Pikachu Backpack', 'Yellow M', 'School Accessory'),
	(3, 'Barbie', 'Doll S', 'Toys'),
	(4, 'Barbie Backpack', 'Pink S', 'School Accessory');

-- Popolamento della tabella Region
INSERT INTO Region (RegionID, RegionName, RegionState)
VALUES 
    (1, 'WestEurope', 'France'),
    (2, 'SouthEurope', 'Spain'),
	(3, 'CentralEurope', 'Germany');

-- Popolamento della tabella Sales
INSERT INTO Sales (SaleID, SaleDate, Amount, ProductID, RegionID)
VALUES 
    (1, '2023-03-19', 1500.00, 1, 1),
    (2, '2023-03-20', 1800.00, 2, 1),
    (3, '2023-03-21', 25.00, 3, 1),
    (4, '2023-03-22', 30.00, 4, 3),
    (5, '2023-03-23', 1200.00, 1, 3),
    (6, '2023-03-24', 1600.00, 2, 2),
    (7, '2023-03-25', 20.00, 3, 3),
    (8, '2023-03-26', 35.00, 4, 2);


SELECT * FROM Product

SELECT * FROM Region

SELECT * FROM Sales