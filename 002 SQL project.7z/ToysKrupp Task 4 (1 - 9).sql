-- 1) Verifica univocit� delle chiavi primarie nella tabella Product
SELECT COUNT(*) AS Num_Records, COUNT(DISTINCT ProductID) AS Unique_Records
FROM Product;

-- 1) Verifica univocit� delle chiavi primarie nella tabella Region
SELECT COUNT(*) AS Num_Records, COUNT(DISTINCT RegionID) AS Unique_Records
FROM Region;

-- 1) Verifica univocit� delle chiavi primarie nella tabella Sales
SELECT COUNT(*) AS Num_Records, COUNT(DISTINCT SaleID) AS Unique_Records
FROM Sales;

-- 2) Elenco delle transazioni con indicazione del tempo trascorso dalla vendita:
SELECT s.SaleID, s.SaleDate, p.ProductName AS Product_Name, p.ProductCategory, r.RegionState AS Region_Country, r.RegionName AS Region_Name, 
    CASE WHEN DATEDIFF(DAY, s.SaleDate, GETDATE()) > 180 THEN 1 ELSE 0 END AS Passed_180_Days
FROM Sales s
JOIN Product p ON s.ProductID = p.ProductID
JOIN Region r ON s.RegionID = r.RegionID;

-- 3) Elenco dei prodotti venduti con il fatturato totale per anno:
SELECT p.ProductName AS Product_Name, YEAR(s.SaleDate) AS Year, SUM(s.Amount) AS Total_Sales
FROM Sales s
JOIN Product p ON s.ProductID = p.ProductID
GROUP BY p.ProductName, YEAR(s.SaleDate);

-- 4) Fatturato totale per stato per anno:
SELECT YEAR(s.SaleDate) AS Year, r.RegionState AS Region_Country, SUM(s.Amount) AS Total_Amount
FROM Sales s
JOIN Region r ON s.RegionID = r.RegionID
GROUP BY YEAR(s.SaleDate), r.RegionState
ORDER BY YEAR(s.SaleDate), Total_Amount DESC;

-- 5) Categoria di articoli maggiormente richiesta:
SELECT TOP 1 p.ProductCategory, COUNT(*) AS Total_Sales
FROM Sales s
JOIN Product p ON s.ProductID = p.ProductID
GROUP BY p.ProductCategory
ORDER BY Total_Sales DESC;

-- 6) Prodotti invenduti - Approccio 1:
SELECT *
FROM Product
WHERE ProductID NOT IN (SELECT DISTINCT ProductID FROM Sales);

-- Approccio 2:
SELECT p.ProductID, p.ProductName
FROM Product p
LEFT JOIN Sales s ON p.ProductID = s.ProductID
WHERE s.SaleID IS NULL;

-- 7) Elenco dei prodotti con l'ultima data di vendita:
SELECT p.ProductID, p.ProductName AS Product_Name, MAX(s.SaleDate) AS LastSaleDate
FROM Product p
LEFT JOIN Sales s ON p.ProductID = s.ProductID
GROUP BY p.ProductID, p.ProductName;

-- 8) Creazione di una vista denormalizzata sui prodotti:
CREATE VIEW ProductView AS
SELECT p.ProductID, p.ProductName AS Product_Name, p.ProductCategory
FROM Product p;

SELECT * FROM ProductView

-- 9) Creazione di una vista denormalizzata sulle informazioni geografiche:
CREATE VIEW Region_Country_View AS
SELECT r.RegionID, r.RegionName AS Region_Name, r.RegionState AS Country
FROM Region r;

SELECT * FROM Region_Country_View
